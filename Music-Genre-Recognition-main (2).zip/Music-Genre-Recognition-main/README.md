# Music-Genre-Recognition
Music Genre Recognition model using Convolutional Neural Networks
